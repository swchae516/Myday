-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 52.79.186.9    Database: teamginnyus
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `age` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('123','2','female','/images/기본사진.png','123','$2a$10$p4cOs8xUBdeevGx9W1ao2OxYPHIihvW.4EM.Uy7JjoP/ePWOXsQ4S'),('123qwe','4','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652970090/pl2pqgpklci5kdf9etfe.jpg','가자','$2a$10$zsLPbbeOZ770Vr0wemVPset8P7dWvmBxYA.CXVEJ2J5UE649tz5/K'),('49','3','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652156466/qtwjmoiy15xcl1lok9ju.jpg','49','$2a$10$BAqr4FEmeVXk7iFzNLx2h.o0uJSDJ1eMJKX.bsGbRjVhf7XZsC9dW'),('499','4','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652857279/ic3rjjmewlnmciirdikq.png','499','$2a$10$yadV20pJYKJ5N9wmLM6lDOx.bNSL3P4DjA7aCZdGGiv2iyb/SJBdW'),('4999','1','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652935631/dc6mn7w9qcmzs9gvlys2.jpg','4999','$2a$10$QyaOnHjD.0xmPy0izgt9duNlTriV2HdeWAPLI4cR.5C71LQZLhKxO'),('a','3','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1653010926/j7hc55mb2emirjcpvxed.png','a','$2a$10$LylTKlrUcc4UIlNgwKyI1OW18e4bQoiM6Q9NKXJ5AGmfHtLrL2dXq'),('a1017','4','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652968168/rbwphibea9yhxuksq4tf.jpg','오늘도 웃자','$2a$10$N/ZQkTb1Iw093SCUgDlQre73IHcYAyQETnfLB0FjydddHe9bUhAia'),('aa','3','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652934392/jdswwlwtgoj9bywal9kd.png','aa','$2a$10$s.5H36thpYz.YqYwXSBI8.9.oE4UEaDeOr2Y8Jxxyp05BbPerQHu6'),('aaa','1','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652163785/in960hhwukdo5j4bk4zg.jpg','aaa1234567890','$2a$10$Bf4jXIQ/nqXaMp8dToRhzeFHzmIYvQ95AkB8LvzrRs3I/UHtZGMY2'),('aaaa','5','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652972305/yxopiwkdwoah3nhs8a87.webp','화이팅','$2a$10$BizNAblz1gRoVHQ.1j34xeQh85A12ExBLr8CaPubkE9IZ9RKswKsq'),('aaaaa','3','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1653011755/iqbpd41btwk18j2g9f9i.png','aaaa','$2a$10$EunqYxuXaPznqSvcwStgHOYNSY6i3w2OhK9y6rVf1Mv2IVyEwrNCy'),('asya390','4','male','/images/기본사진.png','녹쌕222','$2a$10$zKrYcTi.f6uY07.qBjZDdeOa6N0H.ALVQzyl3ZPi5y2VfGRSjubey'),('azocci','5','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652926806/qedghgysdy4ddb6qwtms.jpg','나는50대','$2a$10$Itu7U1we8T5j2RkfNzEz6.zporUPz0vF2UPRGcBWR/bG14ISqAGM6'),('baby','1','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652966153/m0ee1ndk3m4kmvtyjdl4.gif','애기','$2a$10$6nGsYy2XBtpFNPaUeB68we6Rao8z0b5RDZyvXXv/qnK7FdeghZpqG'),('d','1','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652235470/jl0rflqlqulwnfqkcaqf.png','d','$2a$10$YYIQN3csrQoNVenCb8FD1.wz/C54v/tvWzBMwRbe2Rvi9GseMfqLG'),('ginnyseo','3','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652838137/onrptyx2uwm92e9jqcog.jpg','지니지니','$2a$10$l0UVAyNDy6JHkLFRrp9SAOWnAa5v8e9SbYGTOOftPowwmrVo/syo6'),('ginnyus05','3','male','/images/기본사진.png','ginnyus05','$2a$10$HaAIHCnVCynSLWy8dXRI/.wtrawLpvcXWj4i86HFWNaT7N3PTgF8u'),('ginnyus06','5','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652975405/tyijl75gnf2hhk2zywzw.jpg','ginnyus','$2a$10$.OYuFsrNZ22fMxeBh2/nn.OADh2eMmv9AdTDMBbqaAPSEm8aJj5aO'),('hello','3','male','/images/기본사진.png','hello','$2a$10$Zs6L6CbrHsyae6SqL6Jw0epZAbFO1lkwcMyyqQ4v8/4WfKW90r2Rm'),('hello1','3','female','/images/기본사진.png','hello1','$2a$10$FIySHudoT6GjPKz9ox7qt.GppZmA29JY0QezCo4k7gKU6s.AqNKHK'),('hello2','3','male','/images/기본사진.png','hello2','$2a$10$uHQ/CG6VG4gcbtOfi9kiuO.ye2kXthDZnpfu/gJ7FUFPc9OYfoy4q'),('hihi','3','female','/images/기본사진.png','heyyyyyyyyy','$2a$10$BG54i5j7/CXUkJmpv197EOvdbeLdSJiiS0BIgH5ix/F4K4mA3fLU2'),('jasmin960427','2','1','/images/기본사진.png','ginny','$2a$10$acmUzO7u9qLgjXyAulitFOO05Y5KI3iurOGBCe2jKNxA9CYMxHZuu'),('junu','3','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652934579/lxporddye6mnpofiibsq.gif','junu','$2a$10$p2OjWk3p3Zwlg3aeWrouGukqDAcHcTGoXoicdHP43pi/JSFUCvfHO'),('junu2','4','male','/images/기본사진.png','junu2','$2a$10$4dXi1Tli.5ns/AsavKEccuKZhQtRC4VRliDlfcObmbVKbsYzSgGTO'),('kimssafy','3','male','/images/기본사진.png','ssafyssafy','$2a$10$QcTayZ7Tvvoh6xK3tofivOeCaUFrO7sZnnRjKv6h6FOuoAnAZmjJ6'),('qqqq','2','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652975918/oi1bfcuwlupakkenu26j.jpg','qqqq','$2a$10$vZ9qEQHb4YlmrdW00xnjO.mULXX//AxQ1VvqcdxHfpfOjSAeQx2h2'),('ssafy','3','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652171541/hvfxdt9owqnr0lgltqat.jpg','ssafy','$2a$10$NCqHTC46YLUuAug96CHU9eqGAUl.1jnfqgOt3RnNRzusS0McRtkCy'),('ssafycoach',NULL,'male','/images/기본사진.png','양꼬치엔칭따오','$2a$10$cx31kOrW32HiZpHAJjJRqe0q0gk36UhulkrXxxEanafKGC4x6Onf2'),('swchae516','3','male','http://res.cloudinary.com/dusovlxsm/image/upload/v1652167148/boequ8dw2flsakgjpgp9.jpg','swchae516','$2a$10$KKPsQY3Gx78nWaD4VYvZVeDuev0NnHEA9yJEllifxTK0tNGaImmOe'),('test','4','male','/images/기본사진.png','test','$2a$10$JfrD4Fd7WcXbO7HCcoGc8uLCuBzDUlD1Gy1u4D0uwbGefsmurFjPu'),('test3','1','male','string.jpg','test3','$2a$10$yNvXNmLu3phoH9gVwNyhjegim2tbQz5KBRFgEPn3VGOnkp3zmsJay'),('test33','1','female','/images/기본사진.png','test33','$2a$10$.1n5eoXSVoztRhQh4AFxjuYF.qITe3chSKjDjsg8xTTVHb1fw7cMe'),('vv','2','female','http://res.cloudinary.com/dusovlxsm/image/upload/v1652934222/ixnoiwhudbvsu99bcffu.gif','김태형','$2a$10$dXi.bzhPa6rff8JJ8LiBA.NmRvWOJ/Z.r7aA5El9VFRW2NKlJR0qS'),('wow','1','male','/images/기본사진.png','aaa','$2a$10$wujgbkUiTvaGQr156AWF.eI1XGlx4Nz9tiysqCvdqvB9y0uOLwETS'),('ㅇㅇ','1','female','/images/기본사진.png','http://k6c205.p.ssafy.io/','$2a$10$lUS/mjGo99dGYWRk8PFENeiOBAc5UVpOTx1iJfdsEPc.JiPksHSx2'),('잘부탁드립니다','3','male','/images/기본사진.png','잘부탁드립니다','$2a$10$KVzjrTYE2sPQGxub/iJ7P.ozEl9AwH7IBQ7IlpxnOXz7GxAwza3By');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20 11:26:30
