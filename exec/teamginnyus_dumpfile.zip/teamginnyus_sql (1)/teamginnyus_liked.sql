-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 52.79.186.9    Database: teamginnyus
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `liked`
--

DROP TABLE IF EXISTS `liked`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `liked` (
  `lno` bigint NOT NULL,
  `dno` bigint DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`lno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liked`
--

LOCK TABLES `liked` WRITE;
/*!40000 ALTER TABLE `liked` DISABLE KEYS */;
INSERT INTO `liked` VALUES (4,3,'49'),(6,3,'junu'),(14,1,'jasmin960427'),(19,10,'jasmin960427'),(22,2,'jasmin960427'),(24,20,'49'),(207,206,'ssafy'),(208,195,'ssafy'),(238,225,'ssafy'),(244,7,'ssafy'),(248,11,'ssafy'),(249,237,'ssafy'),(276,275,'ssafy'),(288,287,'ssafy'),(294,1,'ssafy'),(986,7,'jasmin960427'),(1008,1007,'hihi'),(1847,1721,'test'),(1848,1721,'junu'),(1970,1969,'test'),(1986,1969,'junu'),(2032,1721,'a'),(2602,134,'swchae516'),(2914,15,'49'),(3291,3272,'ginnyseo'),(3931,1721,'ginnyseo'),(4221,4220,'ginnyseo'),(4227,2442,'ginnyseo'),(4314,2609,'a'),(5765,1721,'junu2'),(5808,5585,'ginnyseo'),(6496,6470,'ginnyseo'),(6632,4993,'ginnyseo'),(6657,6570,'ginnyseo'),(7368,7366,'499'),(8046,1721,'vv'),(8251,7374,'ginnyus06'),(8298,8297,'ginnyus06'),(8466,8297,'vv'),(8493,1721,'ginnyus06'),(8494,8297,'a'),(8641,8520,'vv'),(11060,1721,'baby'),(12172,1721,'a1017'),(12305,4220,'a1017'),(12311,6470,'a1017'),(12327,12292,'123qwe'),(12353,12352,'123qwe'),(12370,12364,'hello2'),(12376,12352,'hello2'),(12382,12098,'hello2'),(12400,8297,'hello2'),(12401,4220,'hello2'),(12403,1721,'hello2'),(12404,1969,'hello2'),(12405,6470,'hello2'),(12406,4993,'hello2'),(12407,5585,'hello2'),(12419,12388,'123qwe'),(12425,11534,'123qwe'),(12431,12063,'123qwe'),(12438,12092,'49'),(12445,12098,'49'),(12452,12063,'49'),(12489,1721,'499'),(12490,8297,'499'),(12512,12063,'ginnyus06'),(12513,12098,'ginnyus06'),(12525,12524,'499'),(12537,6570,'499'),(12695,12524,'ginnyus06'),(12722,12524,'aaaa'),(12728,12098,'aaaa'),(12744,12092,'aaaa'),(12750,12063,'aaaa'),(12757,12352,'aaaa'),(12894,7815,'49'),(12920,12524,'49'),(12922,1721,'49'),(12933,12388,'aaaa'),(12951,11974,'aaaa'),(12957,11652,'aaaa'),(12964,11417,'aaaa'),(12970,6470,'vv'),(12972,6892,'aaaa'),(12974,11534,'aaaa'),(12976,12063,'a'),(12983,12975,'aaaa'),(13041,8304,'ginnyus06'),(13261,9475,'ginnyus06'),(13365,12092,'ginnyus06'),(13438,3155,'49'),(13475,5603,'49'),(13493,13492,'49'),(13499,7242,'49'),(13510,13492,'aaaa'),(13516,13366,'aaaa'),(13528,13047,'aaaa'),(13546,13544,'swchae516'),(13640,13492,'ginnyus06');
/*!40000 ALTER TABLE `liked` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20 11:26:32
