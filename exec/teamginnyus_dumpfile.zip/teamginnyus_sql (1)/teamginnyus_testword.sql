-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 52.79.186.9    Database: teamginnyus
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `testword`
--

DROP TABLE IF EXISTS `testword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `testword` (
  `word` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testword`
--

LOCK TABLES `testword` WRITE;
/*!40000 ALTER TABLE `testword` DISABLE KEYS */;
INSERT INTO `testword` VALUES ('1년 기록'),('DIY'),('OOTD'),('가을 코디'),('건강관리'),('건축물'),('겨울 디저트'),('겨울 코디'),('과학의 날'),('굿즈 컬렉션'),('기분 전환'),('기분전환'),('기억 남는 선물'),('김치 활용 요리'),('나만 알고 싶은 곳'),('나만의 공간'),('나만의 레시피'),('나의 연주'),('남은 명절 음식'),('남은 설날 음식'),('내가 만든 물건'),('내가 만든 요리'),('냉장고 파먹기'),('너의 연주는'),('눈 오는 날'),('다꾸 기록'),('다꾸 일기'),('다꾸를 해요'),('덕질 일기'),('데스크테리어'),('데이트'),('도전! 브이로그'),('동지'),('디저트'),('따뜻하게'),('떡국 만들기'),('랜선 집들이'),('룩북'),('매일 꾸준히'),('매일 하는 일'),('멋진 풍경 자랑'),('물놀이야'),('미술 실력'),('반려동물'),('반려동물 자랑'),('방구석 연주회'),('방구석 집들이'),('보건의 날'),('봄 산책'),('봄 코디'),('브이로그'),('산책 코스'),('삼일절'),('새로 산 물건'),('새로운 취미'),('서툴지만 요리'),('셀프 동영상'),('소풍을 가요'),('손재주'),('손재주 자랑'),('쇼핑 리스트'),('수집품'),('시밀러 룩'),('시밀러룩'),('식목일'),('식물 집사'),('악기 연주'),('애증의 물건'),('애지중지'),('액세서리'),('야경'),('야경 맛집'),('야매 요리'),('야외활동'),('어린이날'),('언박싱'),('여름 별미'),('여름 액세서리'),('여름 코디'),('여행의 추억'),('오늘 하루'),('오늘 한 끼'),('오늘도 운동!'),('오늘의 착장 룩'),('오늘의 한 끼'),('오래된 물건'),('왓츠인 마이 백'),('요리를 해요'),('요즘 이 물건!'),('요즘 필수 템'),('요즘 필수템'),('우리 동네'),('우리 동네 자랑'),('우리 집 밥상'),('우리 집 인테리어'),('운동 기록'),('운동을 해요'),('육아일기'),('음악의 힘'),('인생 사진'),('인생샷'),('인테리어 포인트'),('인테리어의 꽃'),('자신 있는 요리'),('정리 본능'),('정리의 신'),('제철 음식'),('좋아하는 장소'),('집 꾸미기'),('집밥이 최고'),('집에서 운동'),('집콕 취미'),('창문 밖 풍경'),('처서'),('최고의 선물'),('최고의 순간'),('최애 간식'),('최애 관심사'),('최애 음식'),('최애 장소'),('추억 사진'),('추억 여행'),('추울 때 이 음식!'),('취미 기록'),('커피와 함께'),('코덕의 화장대'),('쿠키 만들기'),('쿡방!'),('타임랩스'),('태극기'),('패션 아이템'),('패션 포인트'),('폰꾸를 해요'),('풍경 기록'),('풍경 맛집'),('피크닉'),('하루 루틴'),('하루 일과'),('하루 일기'),('한식'),('혼자 노는 법'),('혼자 놀기'),('혼자서도 잘해요'),('홈 카페'),('홈 카페 놀이'),('홈베이킹'),('홈캉스 즐기기'),('화이트데이'),('힐링');
/*!40000 ALTER TABLE `testword` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20 11:26:30
